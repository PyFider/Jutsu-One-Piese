import eel
eel.init("web")
eel.start('main.html')
